import 'package:flutter/material.dart';
import 'task.dart';

class TaskList extends StatelessWidget {
  final List<Task> tasks;
  final Function(String) onTaskDone;
  final Function(String) onTaskDelete;

  TaskList({
    required this.tasks,
    required this.onTaskDone,
    required this.onTaskDelete,
  });

  @override
  Widget build(BuildContext context) {
    return tasks.isEmpty
        ? Center(
      child: Text(
        'No tasks available.',
        style: TextStyle(fontSize: 16, color: Colors.grey[600]),
      ),
    )
        : ListView.builder(
      itemCount: tasks.length,
      itemBuilder: (ctx, i) {
        final task = tasks[i];
        final isOverdue = task.deadline.isBefore(DateTime.now());
        return Card(
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: isOverdue
                  ? Colors.redAccent
                  : (task.isDone ? Colors.green : Colors.blue),
              child: Icon(
                isOverdue
                    ? Icons.warning
                    : (task.isDone ? Icons.check : Icons.schedule),
                color: Colors.white,
              ),
            ),
            title: Text(task.title),
            subtitle: Text(
              'Deadline: ${task.deadline.year}-${task.deadline.month.toString().padLeft(2, '0')}-${task.deadline.day.toString().padLeft(2, '0')} '
                  '${task.deadline.hour.toString().padLeft(2, '0')}:${task.deadline.minute.toString().padLeft(2, '0')}',
              style: TextStyle(
                color: isOverdue ? Colors.red : Colors.grey[700],
              ),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Hide the Done button if the task is overdue
                if (!task.isDone && !isOverdue)
                  IconButton(
                    icon: Icon(Icons.check, color: Colors.green),
                    onPressed: () => onTaskDone(task.id),
                  ),
                IconButton(
                  icon: Icon(Icons.delete, color: Colors.red),
                  onPressed: () => onTaskDelete(task.id),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
