import 'package:flutter/material.dart';
import 'dart:async'; // For Timer
import 'task.dart';
import 'admin_page.dart';

class UserPage extends StatefulWidget {
  @override
  _UserPageState createState() => _UserPageState();
}

class _UserPageState extends State<UserPage> {
  final List<Task> tasks = [];
  late Timer _timer;

  // Add a new task
  void _addTask(String title, DateTime deadline) {
    final task = Task(
      id: DateTime.now().toString(),
      title: title,
      deadline: deadline,
    );
    setState(() {
      tasks.add(task);
    });
  }

  // Mark a task as done
  void _markTaskDone(String id) {
    setState(() {
      final task = tasks.firstWhere((t) => t.id == id);
      task.isDone = true;
    });
  }

  // Delete a task
  void _deleteTask(String id) {
    setState(() {
      tasks.removeWhere((task) => task.id == id);
    });
  }

  @override
  void initState() {
    super.initState();
    // Timer to periodically check deadlines
    _timer = Timer.periodic(Duration(seconds: 10), (timer) {
      setState(() {
        for (var task in tasks) {
          if (!task.isDone && task.deadline.isBefore(DateTime.now())) {
            // Ensure overdue tasks are properly marked
            task.isDone = false;
          }
        }
      });
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Task Manager'),
        actions: [
          IconButton(
            icon: Icon(Icons.admin_panel_settings),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AdminPage(tasks: tasks),
                ),
              );
            },
          ),
        ],
      ),
      body: tasks.isEmpty
          ? Center(
        child: Text(
          'No tasks available. Start by adding a new task!',
          style: TextStyle(fontSize: 16, color: Colors.grey[600]),
        ),
      )
          : ListView.builder(
        itemCount: tasks.length,
        itemBuilder: (context, index) {
          final task = tasks[index];
          final isOverdue = task.deadline.isBefore(DateTime.now());
          return Card(
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: isOverdue
                    ? Colors.redAccent
                    : (task.isDone ? Colors.green : Colors.blue),
                child: Icon(
                  isOverdue
                      ? Icons.warning
                      : (task.isDone ? Icons.check : Icons.schedule),
                  color: Colors.white,
                ),
              ),
              title: Text(task.title),
              subtitle: Text(
                isOverdue
                    ? 'Deadline passed: ${task.deadline.year}-${task.deadline.month.toString().padLeft(2, '0')}-${task.deadline.day.toString().padLeft(2, '0')} '
                    '${task.deadline.hour.toString().padLeft(2, '0')}:${task.deadline.minute.toString().padLeft(2, '0')}'
                    : 'Deadline: ${task.deadline.year}-${task.deadline.month.toString().padLeft(2, '0')}-${task.deadline.day.toString().padLeft(2, '0')} '
                    '${task.deadline.hour.toString().padLeft(2, '0')}:${task.deadline.minute.toString().padLeft(2, '0')}',
                style: TextStyle(
                  color: isOverdue ? Colors.red : Colors.grey[700],
                ),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Hide the Done button if the task is overdue
                  if (!task.isDone && !isOverdue)
                    IconButton(
                      icon: Icon(Icons.check, color: Colors.green),
                      onPressed: () => _markTaskDone(task.id),
                    ),
                  IconButton(
                    icon: Icon(Icons.delete, color: Colors.red),
                    onPressed: () => _deleteTask(task.id),
                  ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final titleController = TextEditingController();

          DateTime? pickedDate = await showDatePicker(
            context: context,
            initialDate: DateTime.now(),
            firstDate: DateTime.now(),
            lastDate: DateTime(2100),
          );

          if (pickedDate != null) {
            TimeOfDay? pickedTime = await showTimePicker(
              context: context,
              initialTime: TimeOfDay.now(),
            );

            if (pickedTime != null) {
              final deadline = DateTime(
                pickedDate.year,
                pickedDate.month,
                pickedDate.day,
                pickedTime.hour,
                pickedTime.minute,
              );

              showDialog(
                context: context,
                builder: (context) {
                  return AlertDialog(
                    title: Text('Add Task'),
                    content: TextField(
                      controller: titleController,
                      decoration: InputDecoration(labelText: 'Task Title'),
                    ),
                    actions: [
                      TextButton(
                        child: Text('Cancel'),
                        onPressed: () => Navigator.pop(context),
                      ),
                      TextButton(
                        child: Text('Add'),
                        onPressed: () {
                          if (titleController.text.isNotEmpty) {
                            _addTask(
                              titleController.text,
                              deadline,
                            );
                          }
                          Navigator.pop(context);
                        },
                      ),
                    ],
                  );
                },
              );
            }
          }
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
