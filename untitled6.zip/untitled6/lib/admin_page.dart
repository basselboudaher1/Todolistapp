import 'package:flutter/material.dart';
import 'task.dart';

class AdminPage extends StatelessWidget {
  final List<Task> tasks;

  AdminPage({required this.tasks});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Dashboard'),
        backgroundColor: Colors.redAccent,
      ),
      body: tasks.isEmpty
          ? Center(
        child: Text(
          'No tasks available.',
          style: TextStyle(fontSize: 16, color: Colors.grey[600]),
        ),
      )
          : ListView.builder(
        itemCount: tasks.length,
        itemBuilder: (context, index) {
          final task = tasks[index];
          return Card(
            color: task.isDone ? Colors.green[50] : Colors.red[50],
            child: ListTile(
              leading: Icon(
                task.isDone ? Icons.check : Icons.warning,
                color: task.isDone ? Colors.green : Colors.red,
              ),
              title: Text(
                task.title,
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'Deadline: ${task.deadline.year}-${task.deadline.month.toString().padLeft(2, '0')}-${task.deadline.day.toString().padLeft(2, '0')} '
                    '${task.deadline.hour.toString().padLeft(2, '0')}:${task.deadline.minute.toString().padLeft(2, '0')}\n'
                    'Status: ${task.isDone ? "Done" : "Not Done"}',
              ),
            ),
          );
        },
      ),
    );
  }
}
